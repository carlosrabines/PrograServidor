<?php

    function cuenta_ocurrencias($s_aguja, $s_pajar) {
        $n_cuenta = -1;
        if (strlen($s_aguja) <= strlen($s_pajar)) {
            $n_cuenta = substr_count($s_pajar, $s_aguja);
        }

        return $n_cuenta;
    }

    function devuelve_posiciones($s_aguja, $s_pajar) {
        $s_nuevoPajar = $s_pajar;
        $arr_posiciones = [];
        $ncuenta = cuenta_ocurrencias($s_aguja, $s_nuevoPajar);
        if ($ncuenta > 0) {
            $acc_posiciones = 0;
            while ($ncuenta > 0) {
                //guarda posicion donde encontro "aguja" e "nuevopajar" y la agrega al array
                $nposicion = strpos($s_nuevoPajar, $s_aguja);
                $acc_posiciones = $acc_posiciones + $nposicion + 1;
                array_push($arr_posiciones, $acc_posiciones);

                //Rerita la primera ocurrencia "aguja" de "nuevopajar"
                $s_nuevoPajar = substr_replace($s_nuevoPajar,"",$nposicion,strlen($s_aguja));
    //            $s_nuevoPajar = str_replace($s_aguja,"",$s_nuevoPajar);

                //Valida si e3xisten mas ocurrencias de "aguja" en "nuevopajar
                $ncuenta = cuenta_ocurrencias($s_aguja, $s_nuevoPajar);
            }
            return $arr_posiciones;
        } else {
            return false;
        }

    }    

    function pantalla_inicio() {

        $html = "<h1>Funciones de Cadena</h1>"
        ."<form action='{$_SERVER['PHP_SELF']}' method='POST' >\n"
            ."<table>\n"
                ."<tr>\n"
                    ."<td><label for='id_usr'> Cadena aguja: </label><input type='text' id='id_aguja' name='s_aguja' required /></td>\n"
                    ."<td><label for='id_pwd'> Cadena pajar: </label><input type='text' id='id_pajar' name='s_pajar' required /></td>\n"
                    ."<td><button type='submit' value='Encontrar Ocurrencias' >Enviar</button>\n"
              . "</tr>\n"
              . "</table>\n";
        $html .= "</form>\n";

        return $html;
    }

    function pantalla_SegundaLLamada($s_aguja, $s_pajar) {

        $n_veces = 0;
        $html = "<h1>Funciones de Cadena</h1>"
        ."<form action='{$_SERVER['PHP_SELF']}' method='POST' >\n"
            ."<div class='contenedor'>\n"
                ."<div class='columna-izquierda'>\n"
                    ."<button type='submit' value='Remark'>Remark</button>\n"
                    ."<button type='submit' value='Remove'>Remove</button>\n"
                    ."<p>"
                        ."<button type='submit' value='Replace'>Replace</button><br>\n"
                        ."<input type='text' class='texto-izquierda' value='s_replace' />\n"
                    ."</p>"
                    ."<button type='submit' value='Count_Words'>Count Words</button>\n"
                    ."<button type='submit' value='Count_Vowels' >Count Vowels</button>\n"
                    ."<button type='submit' value='Lower_Case'>Lower Case</button>\n"
                    ."<button type='submit' value='Upper_Case' >Upper Case</button>\n"
                ."</div>\n"
                ."<div class='columna-centro'>\n"
                ."</div>\n"
                ."<div class='columna-derecha'>\n"
                    ."<button type='submit' value='Refresh'>Refresh</button>\n"
                ."</div>\n"
            ."</div>\n";

/*
            ."<tr>\n"
                    ."<td><label for='id_usr'> Cadena aguja: </label><input type='text' id='id_aguja' name='s_aguja' required /></td>\n"
                    ."<td><label for='id_pwd'> Cadena pajar: </label><input type='text' id='id_pajar' name='s_pajar' required /></td>\n"
                    ."<td><button type='submit' value='Encontrar Ocurrencias' >Enviar</button>\n"
              . "</tr>\n"
              . "</table>\n"
              . "<p>La cadena aguja aparece [ $n_veces ] en la cadena pajar</p>";
*/

        $html .= "</form>\n";
        return $html;
    }

    function pantalla_MuestraPosicionesPantalla($s_aguja, $s_pajar) {

        $arr_resultado = devuelve_posiciones($s_aguja, $s_pajar);

        if (!$arr_resultado) {
            $html = "Ejecutado, listo  para mostrar resultados: << NO HAY POSICIONESD A MOSTRAR >>";
        } else {
            if (count($arr_resultado) > 0) {
                $html = "Ejecutado, listo  para mostrar resultados - posicionesa: ";
                foreach ($arr_resultado as $result) {
                    $html .= "<br>";
                    $html .= " - " . $result;
                }
            } else {
                $html = "Ejecutado, listo  para mostrar resultados: << NO HAY POSICIONESD A MOSTRAR >>";
            }
        }

    }

?>