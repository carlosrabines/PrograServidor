
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Redirigir</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php

        require("files/funciones.php");

        $mi_Heredoc= "";

        //Si no hay dato principal (se deben validar todos)
        if(!isset($_REQUEST["s_usr"]) || !isset($_REQUEST["s_pwd"])) {
            $mi_Heredoc = pantalla_inicio();
        } else {

            $s_usr = $_POST['s_usr'];
            $s_pwd = $_POST['s_pwd'];

            $validacion_usuario = 4;
            $validacion_usuario = valida_usuario($s_usr, $s_pwd);

            $msj = "Error inesperado validando usuario !!";
            switch ($validacion_usuario) {
                case 0:
                    $msj = "Usuario no existe !!";
                    break;
                case 1:
                    $msj = "Validación correcta !!";
                    break;
                case 2:
                    $msj = "Contraseña incorrecta !!";
                    break;
                default:
                    $msj = "Error inesperado validando usuario !!";
                    break;
            }            

            $mi_Heredoc = pantalla_SegundaLLamada($s_usr, $s_pwd);
            $mi_Heredoc .= " <br> - " . $msj;

            header("Location: verdatos.php");

            // detener el script
            exit;


        }
        echo $mi_Heredoc;
    ?>
        
</body>
</html>